import torch

dtype = torch.FloatTensor
test_batch_size = 2000
validation_interval = 1
